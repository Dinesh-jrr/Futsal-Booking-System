
"use client"
import AdminPaymentListings from "@/components/AdminPaymentListing"
export default function Home() {
  return (
    <div className="p-8">

      <AdminPaymentListings/>
     
    </div>
  );
}
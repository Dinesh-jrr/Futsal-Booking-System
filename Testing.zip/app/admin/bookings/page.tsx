
"use client"
import AdminBookingListings from "@/components/AdminBookingListing"
export default function Home() {
  return (
    <div className="p-8">

      <AdminBookingListings/>
     
    </div>
  );
}
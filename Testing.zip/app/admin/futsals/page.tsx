
"use client"
import AdminFutsalListings from "@/components/AdminFutsalListing"
export default function Home() {
  return (
    <div className="p-8">

      <AdminFutsalListings/>
     
    </div>
  );
}
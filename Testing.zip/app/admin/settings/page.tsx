
"use client"
import AdminSettings from "../../../components/AdminSettings";
export default function Home() {
  return (
    <div className="p-8">

      <AdminSettings/>
     
    </div>
  );
}
'use client';
import { useEffect } from "react";



export default function LoginProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  
    return (
      <>
      {children}
      </>
    );
  } 
